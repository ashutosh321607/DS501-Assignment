
from flask import app,Flask, render_template,request
from flask_restful import Resource, Api, reqparse
import elasticsearch
from elasticsearch import Elasticsearch
import datetime
import concurrent.futures
import requests
import json



app = Flask(__name__)
api = Api(app)

#------------------------------------------------------------------------------------------------------------

NODE_NAME = 'netflix_final'
es = Elasticsearch()

#------------------------------------------------------------------------------------------------------------


class Movies(Resource):
    def __init__(self):
        self.query = parser.parse_args().get("query", None)
        self.child = parser.parse_args().get("child",None)
        self.baseQueryA = {
                "query": {
                    "match": {
                        "title.edgengram": None
                    }
                }
            }
        self.baseQueryB ={
                "query": {
                    "bool": {
                        "should": [
                            {"match": {
                                "title.edgengram": None
                            }}
                        ],
                        "must_not": [
                            {"terms": {"rating.keyword": ["R", "TV-PG", 'PG', 'PG-13', 'NC-17', '']}}
                        ],

                        "boost": 1.0
                    }
                }
            }

    def get(self):
        print("In")
        value = str(self.query)
        child = str(self.child)
        print(value)
        print(child)
        ret_list=[]
        if child == "False":
            self.baseQueryA['query']['match']['title.edgengram']="{}".format(value)
            res = es.search(index=NODE_NAME, body=self.baseQueryA)
            for index, item in enumerate(res['hits']['hits']):
                ret_list.append({'title': item['_source']['title'], 'director': [item['_source']['director']],
                                 'rating': item['_source']['rating']})
            return ret_list
        elif child == "True":
            self.baseQueryB['query']['bool']['should'][0]['match']['title.edgengram']="{}".format(value)
            res = es.search(index=NODE_NAME, body=self.baseQueryB)
            for index, item in enumerate(res['hits']['hits']):
                ret_list.append({'title': item['_source']['title'], 'director': [item['_source']['director']],
                                 'rating': item['_source']['rating']})
            return ret_list

        #self.baseQuery["query"]["bool"]["should"][0]["wildcard"]["title"]["value"] = "{}*".format(value)
        #res = es.search(index=NODE_NAME, size=0, body=self.baseQuery)
        #print("arguments are" +str(reqparse.RequestParser.parse_args(self)))
        return ret_list
class Prefix_Match_endpoint(Resource):
    def __init__(self):
        self.query=parser.parse_args().get("query", None)
        self.BaseQuery={
                  "query": {
                    "regexp": {
                      "description.keywordstring": {
                        "value": None,
                        "flags": "ALL",
                        "case_insensitive": True,
                        "max_determinized_states": 10000,
                        "rewrite": "constant_score"
                      }
                    }
                  }
                }
    def get(self):
        value=self.query
        if value is not None:
            query_string = value + '.*'
        else:
            query_string=None
        ret_list=[]
        #print(query_string)
        self.BaseQuery["query"]["regexp"]["description.keywordstring"]["value"] = "{}*".format(query_string)
        res = es.search(index=NODE_NAME, body=self.BaseQuery)


        for index, item in enumerate(res['hits']['hits']):
            ret_list.append({'title': item['_source']['title'], 'director': [item['_source']['director']],
                             'description': item['_source']['description']})
        return ret_list
class Paginated_List(Resource):
    def __init__(self):
        self.from_ = parser.parse_args().get("from", None)
        self.size_ = parser.parse_args().get("size", None)
        self.Base_Query ={
              "query": {
                  "match_all": {}
              },

                "from": None,
                "size": None,
                "sort": [
                    { "release_year": "desc" }
                ],
            }
    def get(self):
        from_=self.from_
        size_=self.size_
        ret_list=[]
        print("")
        if from_ != None and size_ !=None:
            self.Base_Query["from"]=str((int(from_) - 1)*int(size_))
            self.Base_Query["size"]=size_
            res = es.search(index='netflix-testing2', body=self.Base_Query)


            for index, item in enumerate(res['hits']['hits']):
                ret_list.append({'title': item['_source']['title'], 'director': [item['_source']['director']],
                                 'release_year': item['_source']['release_year']})
        return ret_list
class Phrase_Match(Resource):
    def __init__(self):
        self.field = parser.parse_args().get("field", None)
        self.fields=['type','title','director','cast','country','date_added','release_year','rating','duration','listed_in','description']
        self.phrase = parser.parse_args().get("phrase", None)
        self.Base_Query ={
                  "query": {
                    "bool": {
                      "must": [
                         {"match_phrase": None}
                      ]
                    }
                 }
                }
    def get(self):
        field=self.field
        phrase=self.phrase
        ret_list=[]
        if field in self.fields:
            self.Base_Query['query']['bool']['must'][0]['match_phrase']={'{}'.format(field):'{}'.format(phrase)}
            res = es.search(index=NODE_NAME, body=self.Base_Query)


            for index, item in enumerate(res['hits']['hits']):
                ret_list.append({'title': item['_source']['title'], field: [item['_source'][field]]})
        else:
            ret_list.append('specify field correctly')
        return ret_list



@app.route('/',methods=['GET','POST'])
def index():
    return render_template('home.html')
parser = reqparse.RequestParser()
parser.add_argument("query", type=str, required=False, help="title parameter is Required ")
parser.add_argument("child", type=str, required=False, help="title parameter is Required ")
parser.add_argument("from", type=str, required=False, help="title parameter is Required ")
parser.add_argument("size", type=str, required=False, help="title parameter is Required ")
parser.add_argument("field", type=str, required=False, help="title parameter is Required ")
parser.add_argument("phrase", type=str, required=False, help="title parameter is Required ")

api.add_resource(Movies, '/autocomplete')
api.add_resource(Prefix_Match_endpoint,'/prefixmatchendpoint')
api.add_resource(Paginated_List,'/paginatedlist')
api.add_resource(Phrase_Match,'/phrasematch')



if __name__ == '__main__':
    app.run(debug=True)